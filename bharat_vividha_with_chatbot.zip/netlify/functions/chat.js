// Netlify serverless function — keeps the Gemini API key private on the server.
// The key is read from an environment variable, never from client code.

exports.handler = async function (event) {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method Not Allowed" };
  }

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Server is missing GEMINI_API_KEY. Set it in Netlify Site settings → Environment variables." })
    };
  }

  let userMessage, history;
  try {
    const body = JSON.parse(event.body || "{}");
    userMessage = body.message;
    history = Array.isArray(body.history) ? body.history : [];
  } catch (e) {
    return { statusCode: 400, body: JSON.stringify({ error: "Invalid request body" }) };
  }

  if (!userMessage || typeof userMessage !== "string") {
    return { statusCode: 400, body: JSON.stringify({ error: "Missing 'message' field" }) };
  }

  const systemPrompt = `You are the Bharat Vividha Cultural Guide, an AI assistant for a platform about India's visible heritage (monuments, temples, forts, archaeological and natural sites) and intangible heritage (festivals, folk arts, music, rituals, crafts, language, cuisine).
Answer questions about Indian heritage sites, culture, festivals, travel planning, and traditions accurately and warmly, in a few concise paragraphs.
If asked about something outside Indian heritage/culture/travel, gently redirect to what you can help with.
If unsure of a specific fact, say so rather than guessing.`;

  const contents = [
    ...history.map(h => ({
      role: h.role === "assistant" ? "model" : "user",
      parts: [{ text: h.text }]
    })),
    { role: "user", parts: [{ text: userMessage }] }
  ];

  try {
    const resp = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${apiKey}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          system_instruction: { parts: [{ text: systemPrompt }] },
          contents,
          generationConfig: { maxOutputTokens: 500, temperature: 0.7 }
        })
      }
    );

    const data = await resp.json();

    if (!resp.ok) {
      return {
        statusCode: resp.status,
        body: JSON.stringify({ error: data.error?.message || "Upstream API error" })
      };
    }

    const reply = data?.candidates?.[0]?.content?.parts?.[0]?.text
      || "Sorry, I couldn't generate a response just then. Please try again.";

    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ reply })
    };
  } catch (err) {
    return { statusCode: 500, body: JSON.stringify({ error: "Failed to reach the AI service." }) };
  }
};
